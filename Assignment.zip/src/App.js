// import logo from './logo.svg';
import './App.css';
import { Routing } from './Route';

function App() {
  return (
    <div className="App">
      <Routing/>
    </div>
  );
}

export default App;
